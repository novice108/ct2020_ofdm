import numpy
from gnuradio import gr
import pmt

import os
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend
import codecs

textboxValue = ""

class msg_block(gr.basic_block):
	def __init__(self):
		gr.basic_block.__init__(self,
			name = "msg_block",
			in_sig = None,
			out_sig = None)
		self.message_port_register_in(pmt.intern('msg_in'))
		self.message_port_register_out(pmt.intern('out'))
		self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)

	def handle_msg(self, msg):
		global textboxValue
		textboxValue = pmt.symbol_to_string (msg)
		print("textboxValue")
		print(textboxValue)
		_len = len(textboxValue) # get length of string
		#key_str = b"12345678123456781234567812345678"
		#test_key = key_str.decode("hex")
		#message = b"87654321876543218765432187654321"
		message = b"0123456789ABCDEF"
		iv = os.urandom(16)
		test_key = os.urandom(16)
		aesCipher = Cipher(algorithms.AES(test_key),
				modes.CBC(iv),
				backend = default_backend())
		aesEncryptor = aesCipher.encryptor()
		aesDecryptor = aesCipher.decryptor()
		print("message")
		print(message)
		ciphertext = aesEncryptor.update(message)
		print("ciphertext")
		print(ciphertext)
		print(type(ciphertext))
		print(map(ord,ciphertext))

		print(codecs.decode(ciphertext,'utf-7','ignore'))
		if (_len > 0):
			textboxValue += "\n"
			_len += 1
			a = numpy.zeros(_len,dtype=numpy.uint8)
			a = numpy.array([ord(c) for c in textboxValue])
			a = numpy.zeros(32,dtype=numpy.uint8)
			b = numpy.zeros(32,dtype=numpy.uint8)
			b = a[0:32]
			textboxValue = ""
			#print(type(b))
			#print(b)
			#print(len(b))
		self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
		#self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
		#self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
