import numpy
from gnuradio import gr
import pmt

class msg_block(gr.basic_block):
	def __init__(self):
		gr.basic_block.__init__(self,
			name = "pduToStr",
			in_sig = None,
			out_sig = None)
		self.message_port_register_in(pmt.intern('pdu_in'))
		self.message_port_register_out(pmt.intern('out'))
		self.set_msg_handler(pmt.intern('pdu_in'), self.handle_msg)

	def handle_msg(self, msg):
		#textb = pmt.symbol_to_string (msg)
		J2 = pmt.cdr(msg)
		J3 = pmt.to_python(J2)
		#ascii codes of message
		#a_str = ','.join(str(x).encode('utf-7','ignore') for x in J3)
		#print(a_str)
		s = J3.tostring()
		self.message_port_pub(pmt.intern('out'), pmt.intern(("input message is " + s)))