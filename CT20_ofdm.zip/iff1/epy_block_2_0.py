import numpy
from gnuradio import gr

import pmt

textboxValue = ""

class msg_block(gr.basic_block):
	def __init__(self):
		gr.basic_block.__init__(self,
			name = "msg_block",
			in_sig = None,
			out_sig = None)
		self.message_port_register_in(pmt.intern('msg_in'))
		self.message_port_register_out(pmt.intern('out'))
		self.set_msg_handler(pmt.intern('msg_in'), self.handle_msg)

	def handle_msg(self, msg):
		global textboxValue
		textboxValue = pmt.symbol_to_string (msg)
		# get length of string
		_len = len(textboxValue)
		if (_len > 0):
			#textboxValue += "\n"
			_len += 1
			b = numpy.zeros(_len,dtype=numpy.uint8)
			b = numpy.array([ord(c) for c in textboxValue])
			textboxValue = ""
			#print(type(b))
			#print(b)
		#self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
		#self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
		self.message_port_pub(pmt.intern('out'), pmt.cons(pmt.make_dict(), pmt.pmt_to_python.numpy_to_uvector(numpy.array(b, numpy.uint8))))
